package com.airline.services.pricing;

public interface PricingStrategy {
    double calculate(double basePrice);
}
